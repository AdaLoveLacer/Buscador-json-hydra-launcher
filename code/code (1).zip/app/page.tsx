"use client"

import { useState, useEffect, useMemo } from "react"
import SearchBar from "@/components/search-bar"
import AdvancedFilters from "@/components/advanced-filters"
import DownloadCard from "@/components/download-card"
import SearchStats from "@/components/search-stats"
import FileUploadDialog from "@/components/file-upload-dialog"
import SourcesManager from "@/components/sources-manager"
import { Card } from "@/components/ui/card"
import { Search, Settings } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const MOCK_GOGS: GogData[] = [
  {
    name: "GOG",
    downloads: [
      {
        fileSize: "N/A",
        uploadDate: "2025-04-04T02:30:44.000Z",
        uris: ["magnet:?xt=urn:btih:380D26AB350E162C9E5F50C72672421743CB968D"],
        title: "Warhammer 40000: Battlesector v1.04.163+DLCs",
        source: "GOG",
      },
      {
        fileSize: "17.47 GB",
        uploadDate: "2025-04-04T02:32:07.000Z",
        uris: ["magnet:?xt=urn:btih:5932B52EA22A19F33D431F0060F29A04D599D0ED"],
        title: "Stellaris v3.14.1592653+allDLC",
        source: "GOG",
      },
      {
        fileSize: "1.53 GB",
        uploadDate: "2025-04-06T11:31:51.000Z",
        uris: ["magnet:?xt=urn:btih:DDF670C5CEF241742043CD2534F83F51AEBC5E67"],
        title: "Baldur's Gate 3 v1.8.0",
        source: "GOG",
      },
    ],
  },
]

interface DownloadType {
  fileSize: string
  uploadDate: string
  uris: string[]
  title: string
  source: string
}

interface GogData {
  name: string
  downloads: DownloadType[]
}

interface FilterState {
  searchQuery: string
  sortBy: "date" | "size" | "name"
  dateRange: { from?: Date; to?: Date }
  sizeRange: { min?: number; max?: number }
  searchMode: "all" | "any"
}

export default function Home() {
  const [gogs, setGogs] = useState<GogData[]>(MOCK_GOGS)
  const [allDownloads, setAllDownloads] = useState<DownloadType[]>([])
  const [savedSources, setSavedSources] = useState<
    { name: string; url: string; type: "file" | "url"; lastUpdated: string }[]
  >([])
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: "",
    sortBy: "date",
    dateRange: {},
    sizeRange: {},
    searchMode: "all",
  })

  useEffect(() => {
    const saved = localStorage.getItem("gog-sources")
    if (saved) {
      try {
        setSavedSources(JSON.parse(saved))
      } catch (error) {
        console.error("[v0] Error loading saved sources:", error)
      }
    }
  }, [])

  useEffect(() => {
    const loadUrlSources = async () => {
      for (const source of savedSources.filter((s) => s.type === "url")) {
        try {
          const response = await fetch(source.url)
          if (response.ok) {
            const json = (await response.json()) as GogData
            if (json.name && json.downloads && Array.isArray(json.downloads)) {
              const sourceData = {
                ...json,
                downloads: json.downloads.map((dl) => ({
                  ...dl,
                  source: `${json.name} (URL)`,
                })),
              }
              setGogs((prev) => {
                const filtered = prev.filter(
                  (g) => g.name !== sourceData.name || g.downloads[0]?.source?.includes("URL"),
                )
                return [...filtered, sourceData]
              })
              setSavedSources((prev) =>
                prev.map((s) => (s.url === source.url ? { ...s, lastUpdated: new Date().toISOString() } : s)),
              )
            }
          }
        } catch (error) {
          console.error(`[v0] Error loading source ${source.url}:`, error)
        }
      }
    }

    if (savedSources.length > 0) {
      loadUrlSources()
      const interval = setInterval(loadUrlSources, 60 * 60 * 1000) // Auto-update every hour
      return () => clearInterval(interval)
    }
  }, [savedSources])

  useEffect(() => {
    localStorage.setItem("gog-sources", JSON.stringify(savedSources))
  }, [savedSources])

  useEffect(() => {
    const allDL = gogs.flatMap((gog) => gog.downloads)
    setAllDownloads(allDL)
  }, [gogs])

  const handleFileUpload = (newGogData: GogData, sourceUrl?: string) => {
    setGogs((prev) => [...prev, newGogData])
    if (sourceUrl) {
      setSavedSources((prev) => {
        const exists = prev.some((s) => s.url === sourceUrl)
        if (!exists) {
          return [
            ...prev,
            { name: newGogData.name, url: sourceUrl, type: "url", lastUpdated: new Date().toISOString() },
          ]
        }
        return prev
      })
    } else {
      setSavedSources((prev) => [
        ...prev,
        { name: newGogData.name, url: "", type: "file", lastUpdated: new Date().toISOString() },
      ])
    }
  }

  const handleRemoveSource = (sourceName: string) => {
    setGogs((prev) => prev.filter((g) => g.name !== sourceName))
    setSavedSources((prev) => prev.filter((s) => s.name !== sourceName))
  }

  const filteredDownloads = useMemo(() => {
    let results = [...allDownloads]

    if (filters.searchQuery.trim()) {
      const keywords = filters.searchQuery
        .toLowerCase()
        .split(/\s+/)
        .filter((k) => k.length > 0)

      results = results.filter((item) => {
        const title = item.title.toLowerCase()
        if (filters.searchMode === "all") {
          return keywords.every((keyword) => title.includes(keyword))
        } else {
          return keywords.some((keyword) => title.includes(keyword))
        }
      })
    }

    if (filters.dateRange.from || filters.dateRange.to) {
      results = results.filter((item) => {
        const uploadDate = new Date(item.uploadDate)
        if (filters.dateRange.from && uploadDate < filters.dateRange.from) return false
        if (filters.dateRange.to && uploadDate > filters.dateRange.to) return false
        return true
      })
    }

    if (filters.sizeRange.min !== undefined || filters.sizeRange.max !== undefined) {
      results = results.filter((item) => {
        const size = parseFileSize(item.fileSize)
        if (size === 0) return filters.sizeRange.min === undefined || filters.sizeRange.min === 0
        if (filters.sizeRange.min !== undefined && size < filters.sizeRange.min) return false
        if (filters.sizeRange.max !== undefined && size > filters.sizeRange.max) return false
        return true
      })
    }

    const sorted = [...results]
    if (filters.sortBy === "date") {
      sorted.sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime())
    } else if (filters.sortBy === "name") {
      sorted.sort((a, b) => a.title.localeCompare(b.title))
    } else if (filters.sortBy === "size") {
      sorted.sort((a, b) => parseFileSize(b.fileSize) - parseFileSize(a.fileSize))
    }

    return sorted
  }, [allDownloads, filters])

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                <Search className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">GOG Search</h1>
                <p className="text-sm text-muted-foreground">Pesquisa avançada em arquivos GOG</p>
              </div>
            </div>
            <FileUploadDialog onFileUpload={handleFileUpload} />
          </div>

          <SearchBar value={filters.searchQuery} onChange={(value) => setFilters({ ...filters, searchQuery: value })} />
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="search" className="w-full">
          <TabsList className="mb-6 bg-muted/50">
            <TabsTrigger value="search" className="gap-2">
              <Search className="w-4 h-4" />
              Pesquisa
            </TabsTrigger>
            <TabsTrigger value="sources" className="gap-2">
              <Settings className="w-4 h-4" />
              Fontes ({savedSources.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="search">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
              <div className="lg:col-span-1">
                <AdvancedFilters
                  filters={filters}
                  onFiltersChange={setFilters}
                  totalResults={filteredDownloads.length}
                />
              </div>

              <div className="lg:col-span-4">
                <SearchStats
                  total={allDownloads.length}
                  filtered={filteredDownloads.length}
                  query={filters.searchQuery}
                />

                {filteredDownloads.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredDownloads.map((download, index) => (
                      <DownloadCard key={index} download={download} />
                    ))}
                  </div>
                ) : (
                  <Card className="p-12 text-center bg-card border-border">
                    <Search className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-semibold text-foreground mb-2">Nenhum resultado encontrado</h3>
                    <p className="text-muted-foreground">Tente ajustar sua busca ou filtros</p>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sources">
            <SourcesManager sources={savedSources} onRemoveSource={handleRemoveSource} />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}

function parseFileSize(sizeStr: string): number {
  if (!sizeStr || sizeStr === "N/A") return 0
  const match = sizeStr.match(/[\d.]+/)
  if (!match) return 0
  const num = Number.parseFloat(match[0])
  if (sizeStr.includes("GB")) return num * 1024 * 1024 * 1024
  if (sizeStr.includes("MB")) return num * 1024 * 1024
  if (sizeStr.includes("KB")) return num * 1024
  return num
}
