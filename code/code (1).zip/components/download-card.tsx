"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Copy, Calendar, HardDrive, LinkIcon, ExternalLink, Globe, FileJson } from "lucide-react"

interface DownloadItem {
  fileSize: string
  uploadDate: string
  uris: string[]
  title: string
  source: string
}

export default function DownloadCard({ download }: { download: DownloadItem }) {
  const [copied, setCopied] = useState(false)
  const [showLinks, setShowLinks] = useState(false)

  const isUrlSource = download.source.includes("(URL)")
  const sourceDisplay = download.source.replace(" (URL)", "")

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  return (
    <Card className="overflow-hidden border-border bg-card hover:bg-card/80 transition-colors group">
      <div className="p-4">
        {/* Title */}
        <h3 className="font-semibold text-foreground mb-3 line-clamp-2 text-sm group-hover:text-primary transition">
          {download.title}
        </h3>

        {/* Metadata */}
        <div className="space-y-2 mb-4 text-xs">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="w-4 h-4" />
            <span>{formatDate(download.uploadDate)}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <HardDrive className="w-4 h-4" />
            <span className="font-medium">{download.fileSize}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            {isUrlSource ? (
              <Globe className="w-4 h-4 text-accent" />
            ) : (
              <FileJson className="w-4 h-4 text-muted-foreground" />
            )}
            <span
              className={`text-xs px-2 py-1 rounded font-medium ${isUrlSource ? "bg-accent/20 text-accent" : "bg-muted/50 text-primary"}`}
            >
              {sourceDisplay} {isUrlSource && "• URL"}
            </span>
          </div>
        </div>

        {/* Links Preview */}
        {download.uris.length > 0 && (
          <div className="mb-4 p-3 bg-muted/50 rounded-md">
            <div className="flex items-center gap-2 text-xs font-medium text-foreground mb-2">
              <LinkIcon className="w-4 h-4" />
              {download.uris.length} link{download.uris.length > 1 ? "s" : ""}
            </div>
            <a
              href={download.uris[0]}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-primary hover:text-primary/80 line-clamp-2 break-all flex items-start gap-1 group/link"
            >
              <ExternalLink className="w-3 h-3 flex-shrink-0 mt-0.5" />
              <span className="hover:underline">{download.uris[0]}</span>
            </a>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => copyToClipboard(download.uris[0] || "")}
            disabled={!download.uris[0]}
            className="flex-1 gap-1 text-xs"
          >
            <Copy className="w-3 h-3" />
            {copied ? "Copiado!" : "Copiar Link"}
          </Button>
          {download.uris.length > 1 && (
            <Button variant="ghost" size="sm" onClick={() => setShowLinks(!showLinks)} className="text-xs">
              {download.uris.length - 1}+
            </Button>
          )}
        </div>

        {/* Additional Links */}
        {showLinks && download.uris.length > 1 && (
          <div className="mt-3 pt-3 border-t border-border space-y-2">
            {download.uris.slice(1).map((uri, idx) => (
              <a
                key={idx}
                href={uri}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full text-left text-xs p-2 bg-muted/30 rounded hover:bg-muted/50 transition truncate text-primary hover:text-primary/80 flex items-center gap-1"
              >
                <ExternalLink className="w-3 h-3 flex-shrink-0" />
                Link {idx + 2}
              </a>
            ))}
          </div>
        )}
      </div>
    </Card>
  )
}
