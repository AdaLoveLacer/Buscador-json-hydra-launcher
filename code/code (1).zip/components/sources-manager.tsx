"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Trash2, Globe, FileJson, RotateCw } from "lucide-react"

interface Source {
  name: string
  url: string
  type: "file" | "url"
  lastUpdated: string
}

export default function SourcesManager({
  sources,
  onRemoveSource,
}: {
  sources: Source[]
  onRemoveSource: (name: string) => void
}) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  if (sources.length === 0) {
    return (
      <Card className="p-12 text-center bg-card border-border">
        <FileJson className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
        <h3 className="text-lg font-semibold text-foreground mb-2">Nenhuma fonte carregada</h3>
        <p className="text-muted-foreground">Carregue arquivos JSON ou URLs para começar a pesquisar</p>
      </Card>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {sources.map((source) => (
        <Card key={source.name} className="p-4 bg-card border-border hover:border-primary/50 transition-colors">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              {source.type === "url" ? (
                <Globe className="w-5 h-5 text-accent flex-shrink-0" />
              ) : (
                <FileJson className="w-5 h-5 text-primary flex-shrink-0" />
              )}
              <div className="min-w-0 flex-1">
                <h3 className="font-semibold text-foreground truncate">{source.name}</h3>
                {source.type === "url" && <p className="text-xs text-muted-foreground truncate">{source.url}</p>}
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onRemoveSource(source.name)}
              className="text-destructive hover:text-destructive hover:bg-destructive/10 flex-shrink-0"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>

          <div className="space-y-2 mb-3">
            <div className="flex items-center gap-2 text-xs">
              <span
                className={`px-2 py-1 rounded font-medium ${source.type === "url" ? "bg-accent/20 text-accent" : "bg-muted/50 text-primary"}`}
              >
                {source.type === "url" ? "URL • Auto-atualiza" : "Arquivo local"}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <RotateCw className="w-3 h-3" />
              <span>Atualizado: {formatDate(source.lastUpdated)}</span>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
