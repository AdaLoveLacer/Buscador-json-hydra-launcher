"use client"

import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RotateCcw } from "lucide-react"

interface FilterState {
  searchQuery: string
  sortBy: "date" | "size" | "name"
  dateRange: { from?: Date; to?: Date }
  sizeRange: { min?: number; max?: number }
  searchMode: "all" | "any"
}

interface AdvancedFiltersProps {
  filters: FilterState
  onFiltersChange: (filters: FilterState) => void
  totalResults: number
}

export default function AdvancedFilters({ filters, onFiltersChange, totalResults }: AdvancedFiltersProps) {
  const resetFilters = () => {
    onFiltersChange({
      searchQuery: filters.searchQuery,
      sortBy: "date",
      dateRange: {},
      sizeRange: {},
      searchMode: "all",
    })
  }

  const updateDateRange = (field: "from" | "to", value: string) => {
    onFiltersChange({
      ...filters,
      dateRange: {
        ...filters.dateRange,
        [field]: value ? new Date(value) : undefined,
      },
    })
  }

  const updateSizeRange = (field: "min" | "max", value: string) => {
    onFiltersChange({
      ...filters,
      sizeRange: {
        ...filters.sizeRange,
        [field]: value ? Number.parseFloat(value) * 1024 * 1024 * 1024 : undefined,
      },
    })
  }

  return (
    <Card className="p-6 bg-card border-border h-fit sticky top-24 space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-foreground">Filtros</h3>
        <button
          onClick={resetFilters}
          className="text-xs text-muted-foreground hover:text-foreground transition flex items-center gap-1"
        >
          <RotateCcw className="w-3 h-3" />
          Limpar
        </button>
      </div>

      <div>
        <Label className="text-sm font-medium text-foreground mb-3 block">Modo de Busca</Label>
        <div className="space-y-2">
          {[
            { id: "all", label: "Todas as palavras" },
            { id: "any", label: "Qualquer palavra" },
          ].map((option) => (
            <button
              key={option.id}
              onClick={() =>
                onFiltersChange({
                  ...filters,
                  searchMode: option.id as "all" | "any",
                })
              }
              className={`w-full text-left px-3 py-2 rounded-md text-sm transition ${
                filters.searchMode === option.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-foreground hover:bg-muted/80"
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>

      {/* Sorting */}
      <div>
        <Label className="text-sm font-medium text-foreground mb-3 block">Ordenar por</Label>
        <div className="space-y-2">
          {[
            { id: "date", label: "Data de Upload (Recente)" },
            { id: "size", label: "Tamanho (Maior)" },
            { id: "name", label: "Nome (A-Z)" },
          ].map((option) => (
            <button
              key={option.id}
              onClick={() =>
                onFiltersChange({
                  ...filters,
                  sortBy: option.id as "date" | "size" | "name",
                })
              }
              className={`w-full text-left px-3 py-2 rounded-md text-sm transition ${
                filters.sortBy === option.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-foreground hover:bg-muted/80"
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>

      {/* Date Range */}
      <div className="space-y-3">
        <Label className="text-sm font-medium text-foreground">Período de Upload</Label>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">De</label>
          <Input
            type="date"
            value={filters.dateRange.from ? filters.dateRange.from.toISOString().split("T")[0] : ""}
            onChange={(e) => updateDateRange("from", e.target.value)}
            className="bg-muted border-border text-sm"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Até</label>
          <Input
            type="date"
            value={filters.dateRange.to ? filters.dateRange.to.toISOString().split("T")[0] : ""}
            onChange={(e) => updateDateRange("to", e.target.value)}
            className="bg-muted border-border text-sm"
          />
        </div>
      </div>

      <div className="space-y-3">
        <Label className="text-sm font-medium text-foreground">Tamanho do Arquivo (GB)</Label>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Mínimo</label>
          <Input
            type="number"
            min="0"
            step="0.5"
            placeholder="Ex: 1"
            value={filters.sizeRange.min ? (filters.sizeRange.min / (1024 * 1024 * 1024)).toFixed(1) : ""}
            onChange={(e) => updateSizeRange("min", e.target.value)}
            className="bg-muted border-border text-sm"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Máximo</label>
          <Input
            type="number"
            min="0"
            step="0.5"
            placeholder="Ex: 50"
            value={filters.sizeRange.max ? (filters.sizeRange.max / (1024 * 1024 * 1024)).toFixed(1) : ""}
            onChange={(e) => updateSizeRange("max", e.target.value)}
            className="bg-muted border-border text-sm"
          />
        </div>
      </div>

      {/* Results Counter */}
      <div className="pt-3 border-t border-border">
        <div className="text-xs text-muted-foreground">
          <span className="font-semibold text-foreground">{totalResults}</span> resultado
          {totalResults !== 1 ? "s" : ""}
        </div>
      </div>
    </Card>
  )
}
