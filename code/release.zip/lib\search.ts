import { DownloadType, GogData } from "./types"
import { getCachedUrl, cacheUrlData } from "./url-cache"

// Tipos para o carregador
export interface SourceItem {
  type: string;
  url: string;
  name?: string;
}

export interface GogSourcesStoreItemWithData {
  type: 'url' | 'file';
  url: string;
  name?: string;
}

export interface GogSource extends SourceItem {
  type: 'url';
  url: string;
}

// Interface para callbacks
export interface LoaderCallbacks {
  onLoadStart?: () => void;
  onLoadEnd?: () => void;
  onAddData: (data: GogData, url?: string) => void;
  onError?: (error: Error) => void;
}

// Tipos relacionados a fontes
export interface SourceItem {
  type: string;
  url: string;
  name?: string;
}

export interface GogSourcesStoreItemWithData {
  type: 'url' | 'file';
  url: string;
  name?: string;
}

export interface GogSource extends SourceItem {
  type: 'url';
  url: string;
}

// Constantes para controle de URLs
export const processedUrlLoads = new Set<string>()
export const recentlyRemovedUrls = new Set<string>()
export const failedUrlAt: Record<string, number> = {}
export const FAILED_URL_RETRY_MS = 10 * 60 * 1000 // 10 minutes

// Type guard para validar a estrutura dos dados JSON
export function isValidGogData(json: unknown): json is GogData {
  if (!json || typeof json !== 'object') return false
  const data = json as Partial<GogData>
  return (
    typeof data.name === 'string' &&
    Array.isArray(data.downloads) &&
    data.downloads.every(dl => 
      typeof dl === 'object' &&
      dl !== null &&
      typeof dl.title === 'string' &&
      typeof dl.fileSize === 'string' &&
      typeof dl.uploadDate === 'string' &&
      Array.isArray(dl.uris)
    )
  )
}

// Lightweight fetch with timeout using AbortController
export async function fetchWithTimeout(input: RequestInfo, init: RequestInit = {}, timeoutMs = 10000) {
  const controller = new AbortController()
  const id = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const res = await fetch(input, { ...init, signal: controller.signal })
    return res
  } finally {
    clearTimeout(id)
  }
}

// Função para processar dados do GOG antes de adicionar
export function processGogData(json: GogData): GogData {
  return {
    ...json,
    downloads: json.downloads.map((dl: DownloadType) => ({
      ...dl,
      source: json.name
    }))
  }
}

// Função para carregar uma fonte única
export async function loadSingleSource(
  source: GogSourcesStoreItemWithData,
  callbacks: LoaderCallbacks
): Promise<void> {
  const url = source.url;
  try {
    if (processedUrlLoads.has(url)) return;
    
    // Tentar cache primeiro
    const cached = await getCachedUrl(url);
    if (cached) {
      processedUrlLoads.add(url);
      callbacks.onAddData(cached, url);
      return;
    }

    // Verificar falhas recentes
    const lastFailed = failedUrlAt[url];
    if (lastFailed && Date.now() - lastFailed < FAILED_URL_RETRY_MS) return;
    if (recentlyRemovedUrls.has(url) || recentlyRemovedUrls.has(source?.name || '')) return;

    const res = await fetchWithTimeout(url);
    if (!res?.ok) {
      failedUrlAt[url] = Date.now();
      return;
    }

    const text = await res.text().catch(() => '');
    const trimmed = text.trim();
    if (trimmed.startsWith('<')) {
      console.warn(`Non-JSON response for ${url}`);
      failedUrlAt[url] = Date.now();
      return;
    }

    const json = JSON.parse(text);
    if (!isValidGogData(json)) {
      failedUrlAt[url] = Date.now();
      return;
    }

    await cacheUrlData(url, json);
    processedUrlLoads.add(url);
    callbacks.onAddData(json, url);
  } catch (err: any) {
    if (err?.name === 'AbortError') {
      console.warn('Fetch timeout for', url);
    }
    failedUrlAt[url] = Date.now();
    callbacks.onError?.(err);
  }
}

// Função para carregar múltiplas fontes
export async function loadSources(
  sources: GogSourcesStoreItemWithData[],
  callbacks: LoaderCallbacks
): Promise<void> {
  if (sources.length === 0) return;

  try {
    callbacks.onLoadStart?.();

    const urlSources = sources.filter((s): s is GogSource => 
      s.type === 'url' && typeof s.url === 'string'
    );

    await Promise.all(
      urlSources.map(source => loadSingleSource(source, callbacks))
    );
  } catch (err: any) {
    callbacks.onError?.(err);
  } finally {
    callbacks.onLoadEnd?.();
  }
}

// Função para remover uma fonte
export function markSourceAsRemoved(sourceName: string, url?: string): void {
  if (url) {
    recentlyRemovedUrls.add(url);
    processedUrlLoads.add(url);
  }
  recentlyRemovedUrls.add(sourceName);
}

// Função para verificar se uma fonte já foi processada
export function isSourceProcessed(url: string): boolean {
  return processedUrlLoads.has(url);
}

// Função para marcar uma fonte como processada
export function markSourceAsProcessed(url: string): void {
  processedUrlLoads.add(url);
}

// Interface para dados do servidor
export interface ServerSource {
  id: number;
  name: string;
}

// Constantes
export const API_BASE = 'http://localhost:4000';

// Cache do servidor
let serverListCache: ServerSource[] = [];

// Função para buscar lista do servidor
export async function fetchServerList(): Promise<ServerSource[]> {
  if (serverListCache.length > 0) return serverListCache;
  
  try {
    const res = await fetch(`${API_BASE}/list`);
    if (res.ok) {
      serverListCache = await res.json();
      return serverListCache;
    }
  } catch (e) {
    console.warn('[v0] failed fetching server list:', e);
  }
  return [];
}

// Função para carregar fonte do servidor
export async function loadServerSource(
  source: GogSourcesStoreItemWithData,
  loadSavedSource: (id: string) => Promise<void>
): Promise<boolean> {
  try {
    if (source.type === 'file') {
      if ((source as any).__serverId) {
        await loadSavedSource(String((source as any).__serverId));
        markSourceAsProcessed(source.name || '');
        return true;
      }

      // Tentar encontrar por nome
      const serverList = await fetchServerList();
      const match = serverList.find(it => it.name === source.name);
      if (match) {
        await loadSavedSource(String(match.id));
        markSourceAsProcessed(source.name || '');
        return true;
      }
    }
  } catch (e) {
    console.warn('[v0] failed loading server source:', e);
  }
  return false;
}

// Interface para o estado dos filtros
export interface FilterState {
  searchQuery: string
  sortBy: "date" | "size" | "name"
  dateRange: { from?: Date; to?: Date }
  sizeRange: { min?: number; max?: number }
  searchMode: "all" | "any"
}

// Cache para otimizar a busca
const searchCache = new WeakMap<DownloadType, string>();

// Função para processar tamanho de arquivos
export function parseFileSize(sizeStr: string): number {
  if (!sizeStr || sizeStr === "N/A") return 0
  const match = sizeStr.match(/[\d.]+/)
  if (!match) return 0
  const num = Number.parseFloat(match[0])
  if (sizeStr.includes("GB")) return num * 1024 * 1024 * 1024
  if (sizeStr.includes("MB")) return num * 1024 * 1024
  if (sizeStr.includes("KB")) return num * 1024
  return num
}

  // Função principal de filtragem de resultados
export function filterResults(
  downloads: DownloadType[],
  searchQuery: string,
  searchMode: "all" | "any"
): DownloadType[] {
  if (!searchQuery?.trim()) return downloads;
  if (!downloads?.length) return [];

  // Preparar os termos de busca
  const searchTerms = searchQuery
    .toLowerCase()
    .trim()
    .split(/\s+/)
    .filter(term => term.length > 0);

  // Debug
  console.log('Termos de busca:', searchTerms);

  return downloads.filter(item => {
    if (!item?.title) return false;

    // Função para verificar se o texto contém um termo
    const containsTerm = (text: string, term: string) => {
      text = text.toLowerCase();
      return text.includes(term) || // Correspondência direta
             text.split(/[\s-]+/).some(word => // Correspondência parcial de palavra
               word.startsWith(term) || word.endsWith(term)
             );
    };

    // Preparar o texto de busca
    let searchText = searchCache.get(item);
    if (!searchText) {
      const title = item.title;
      const source = item.source || '';
      searchText = `${title} ${source}`;
      searchCache.set(item, searchText);
    }

    // Verificar se todos os termos correspondem (modo ALL)
    // ou se pelo menos um termo corresponde (modo ANY)
    if (searchMode === "all") {
      const matches = searchTerms.every(term => containsTerm(searchText, term));
      if (matches) {
        console.log('Match encontrado (ALL):', {
          title: item.title,
          terms: searchTerms,
          text: searchText
        });
      }
      return matches;
    } else {
      const matches = searchTerms.some(term => containsTerm(searchText, term));
      if (matches) {
        console.log('Match encontrado (ANY):', {
          title: item.title,
          terms: searchTerms,
          text: searchText
        });
      }
      return matches;
    }
  });
}

// Função para processar e filtrar downloads com todos os filtros
export function processDownloads(
  downloads: DownloadType[],
  filters: FilterState
): DownloadType[] {
  if (!downloads?.length) return [];

  let results = [...downloads]; // Criar cópia para evitar mutação

  // Aplicar filtro de busca primeiro
  if (filters.searchQuery?.trim()) {
    results = filterResults(results, filters.searchQuery, filters.searchMode);
  }

  // Aplicar filtro de data
  if (filters.dateRange.from || filters.dateRange.to) {
    results = results.filter(item => {
      const uploadDate = new Date(item.uploadDate);
      if (filters.dateRange.from && uploadDate < filters.dateRange.from) return false;
      if (filters.dateRange.to && uploadDate > filters.dateRange.to) return false;
      return true;
    });
  }

  // Aplicar filtro de tamanho
  if (filters.sizeRange.min !== undefined || filters.sizeRange.max !== undefined) {
    results = results.filter(item => {
      const size = parseFileSize(item.fileSize);
      if (size === 0) return filters.sizeRange.min === undefined || filters.sizeRange.min === 0;
      if (filters.sizeRange.min !== undefined && size < filters.sizeRange.min) return false;
      if (filters.sizeRange.max !== undefined && size > filters.sizeRange.max) return false;
      return true;
    });
  }

  // Aplicar ordenação
  const sorted = [...results];
  if (filters.sortBy === "date") {
    sorted.sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime());
  } else if (filters.sortBy === "name") {
    sorted.sort((a, b) => a.title.toLowerCase().localeCompare(b.title.toLowerCase()));
  } else if (filters.sortBy === "size") {
    sorted.sort((a, b) => {
      const sizeA = parseFileSize(a.fileSize);
      const sizeB = parseFileSize(b.fileSize);
      return sizeB - sizeA;
    });
  }

  return sorted;
}

// Função para processar downloads e remover duplicatas
export function processAndDeduplicateDownloads(gogs: GogData[]): DownloadType[] {
  const processed = new Map();
  
  return gogs.flatMap((gog) => {
    if (!gog.name) return [];
    
    return gog.downloads
      .filter(dl => {
        if (!dl?.title?.trim() || dl.title === 'Wkeynhk') return false;
        const key = `${dl.title}:${dl.uploadDate}`;
        if (processed.has(key)) return false;
        processed.set(key, true);
        return true;
      })
      .map((dl) => ({
        ...dl,
        source: gog.name,
        fileSizeBytes: parseFileSize(dl.fileSize || '')
      }))
  });
}