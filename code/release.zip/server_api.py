#!/usr/bin/env python3
"""
server_api.py

Pequena API HTTP para armazenar grandes arquivos JSON no servidor em disco
e registrar metadados no SQLite. Endpoints:

- POST /upload  -> aceita multipart/form-data com campo 'file' e opcional 'name'
- GET  /download/<id> -> faz download do arquivo (arquivo gzip salvo)
- GET  /list -> lista metadados (id, name, size, sha256, created_at)
- DELETE /delete/<id> -> remove registro e arquivo associado

Uso (dev):
  pip install flask flask-cors
  python server_api.py

Observações:
- Os arquivos são salvos em uploads/ como <timestamp>-<rand>.json.gz (compressão gzip por padrão).
- O conteúdo é lido em streaming (chunks) para não alocar tudo na memória.
- O SHA256 é calculado sobre o conteúdo original (bytes lidos do upload).
"""

from __future__ import annotations

import os
import sqlite3
import hashlib
import gzip
import datetime
from pathlib import Path
from typing import Tuple, Generator

from flask import Flask, request, jsonify, send_file, abort, Response, stream_with_context
from flask_cors import CORS


BASE = Path(__file__).resolve().parent
UPLOAD_DIR = BASE / "uploads"
DB_PATH = BASE / "db.sqlite"
UPLOAD_DIR.mkdir(exist_ok=True)

CHUNK_SIZE = 64 * 1024


def init_db() -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL;")
    cur.execute("PRAGMA synchronous=NORMAL;")
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS sources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            filename TEXT,
            size INTEGER,
            sha256 TEXT,
            meta TEXT,
            created_at TEXT
        )
        """
    )
    conn.commit()
    conn.close()


def save_stream_to_file(file_stream, dest_path: Path, compress: bool = True) -> Tuple[int, str]:
    """Grava o stream para arquivo no disco (gzip opcional) e retorna (bytes_written, sha256)."""
    hasher = hashlib.sha256()
    written = 0
    temp_path = dest_path.with_suffix(dest_path.suffix + ".tmp")

    if compress:
        with gzip.open(temp_path, "wb") as f:
            while True:
                chunk = file_stream.read(CHUNK_SIZE)
                if not chunk:
                    break
                # chunk é bytes
                f.write(chunk)
                hasher.update(chunk)
                written += len(chunk)
    else:
        with open(temp_path, "wb") as f:
            while True:
                chunk = file_stream.read(CHUNK_SIZE)
                if not chunk:
                    break
                f.write(chunk)
                hasher.update(chunk)
                written += len(chunk)

    # atomic replace
    os.replace(str(temp_path), str(dest_path))
    return written, hasher.hexdigest()


app = Flask(__name__)
CORS(app)


# Retornar erros como JSON para clientes XHR/fetch em vez do HTML padrão do Flask
@app.errorhandler(404)
def handle_404(error):
    return jsonify({"error": "not found"}), 404


@app.errorhandler(500)
def handle_500(error):
    # Em produção, não expor detalhes do erro - aqui logamos e retornamos uma mensagem genérica
    app.logger.exception('internal server error')
    return jsonify({"error": "internal server error"}), 500


@app.route("/upload", methods=["POST"])
def upload():
    # espera multipart/form-data com campo 'file' e opcional 'name'
    if "file" not in request.files:
        return jsonify({"error": "missing file"}), 400

    f = request.files["file"]
    name = request.form.get("name") or f.filename or f"source-{int(datetime.datetime.utcnow().timestamp())}"
    compress = request.form.get("compress", "1") not in ("0", "false", "False")

    # filename: timestamp-rand.json.gz
    suffix = ".json.gz" if compress else ".json"
    filename = f"{int(datetime.datetime.utcnow().timestamp())}-{os.urandom(6).hex()}{suffix}"
    dest_path = UPLOAD_DIR / filename

    try:
        written, sha = save_stream_to_file(f.stream, dest_path, compress=compress)
    except Exception as e:
        app.logger.exception("save_stream_to_file failed")
        return jsonify({"error": "failed to save file", "detail": str(e)}), 500

    # If a file with the same sha256 already exists in DB, delete the just-written
    # file and return the existing id to avoid duplicate stored blobs.
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, filename FROM sources WHERE sha256 = ?", (sha,))
    existing = cur.fetchone()
    if existing:
        existing_id, existing_filename = existing[0], existing[1]
        try:
            # remove the newly written duplicate file
            if dest_path.exists():
                dest_path.unlink()
        except Exception:
            app.logger.exception('failed to remove duplicate upload file %s', dest_path)
        # Log duplicate upload event for observability
        app.logger.info('duplicate upload detected: sha=%s existing_id=%s client=%s filename=%s', sha, existing_id, request.remote_addr, f'{dest_path.name}')
        conn.close()
        return jsonify({"id": existing_id, "name": name, "filename": existing_filename, "size": written, "sha256": sha, "note": "duplicate"}), 200

    # gravar metadados no sqlite
    cur.execute(
        "INSERT INTO sources (name, filename, size, sha256, meta, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (name, filename, written, sha, None, datetime.datetime.utcnow().isoformat()),
    )
    conn.commit()
    id_ = cur.lastrowid
    conn.close()


    app.logger.info('upload stored: id=%s filename=%s size=%s sha=%s client=%s', id_, filename, written, sha, request.remote_addr)

    # Limitar a pasta uploads para os 5 arquivos .json.gz mais recentes
    try:
        gz_files = sorted(
            [f for f in os.listdir(UPLOAD_DIR) if f.endswith('.json.gz')],
            key=lambda f: os.path.getmtime(os.path.join(UPLOAD_DIR, f)),
            reverse=True
        )
        for old_file in gz_files[5:]:
            try:
                os.remove(os.path.join(UPLOAD_DIR, old_file))
                app.logger.info(f'Removido arquivo antigo: {old_file}')
            except Exception as e:
                app.logger.warning(f'Erro ao remover {old_file}: {e}')
    except Exception as e:
        app.logger.warning(f'Erro ao limitar arquivos uploads: {e}')

    return jsonify({"id": id_, "name": name, "filename": filename, "size": written, "sha256": sha}), 201


@app.route("/download/<int:id_>", methods=["GET"])
def download(id_):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT filename FROM sources WHERE id = ?", (id_,))
    row = cur.fetchone()
    conn.close()
    if not row:
        return abort(404)
    file_path = UPLOAD_DIR / row[0]
    if not file_path.exists():
        return abort(404)
    # Serve file as attachment
    return send_file(str(file_path), as_attachment=True, download_name=row[0])


@app.route("/list", methods=["GET"])
def list_sources():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, name, filename, size, sha256, created_at FROM sources ORDER BY created_at DESC")
    rows = cur.fetchall()
    conn.close()
    items = [
        {"id": r[0], "name": r[1], "filename": r[2], "size": r[3], "sha256": r[4], "created_at": r[5]}
        for r in rows
    ]
    return jsonify(items)


@app.route("/delete/<int:id_>", methods=["DELETE"])
def delete_source(id_):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT filename FROM sources WHERE id = ?", (id_,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return jsonify({"error": "not found"}), 404
    filename = row[0]
    cur.execute("DELETE FROM sources WHERE id = ?", (id_,))
    conn.commit()
    conn.close()

    try:
        p = UPLOAD_DIR / filename
        if p.exists():
            p.unlink()
    except Exception as e:
        app.logger.warning("failed to delete file %s: %s", filename, e)

    return jsonify({"deleted": id_})


@app.route("/json/<int:id_>", methods=["GET"])
def get_json(id_):
    """Retorna o conteúdo JSON descomprimido para o registro `id_`.
    Faz streaming da descompressão para não carregar todo o arquivo na memória.
    """
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT filename FROM sources WHERE id = ?", (id_,))
    row = cur.fetchone()
    conn.close()
    if not row:
        return abort(404)

    file_path = UPLOAD_DIR / row[0]
    if not file_path.exists():
        return abort(404)

    def read_file_chunks() -> Generator[bytes, None, None]:
        """Generator function that yields bytes chunks from the file."""
        try:
            # Se o arquivo estiver comprimido (.gz), abra com gzip e leia em chunks
            opener = gzip.open if str(file_path).endswith('.gz') else open
            with opener(file_path, 'rb') as f:
                while True:
                    raw_chunk = f.read(CHUNK_SIZE)
                    if not raw_chunk:
                        break
                    # Garante que estamos sempre retornando bytes
                    if isinstance(raw_chunk, str):
                        chunk = raw_chunk.encode('utf-8')
                    else:
                        chunk = raw_chunk
                    yield chunk
        except Exception:
            app.logger.exception('error streaming json for id=%s', id_)
            yield b''

    # Stream the JSON bytes and set application/json content type 
    chunks = read_file_chunks()
    return Response(chunks, mimetype='application/json')


def setup_environment():
    """Prepara o ambiente Python e Node.js"""
    import subprocess
    import sys
    import time
    import webbrowser
    from shutil import which

    # Verifica requisitos
    if which('node') is None:
        print("Erro: Node.js não encontrado! Por favor, instale o Node.js")
        sys.exit(1)

    # Instala dependências Python se necessário
    subprocess.run([sys.executable, "-m", "pip", "install", "flask", "flask-cors"], check=True)

    # Instala dependências Node.js se necessário
    if not (BASE / "node_modules").exists():
        print("Instalando dependências Node.js...")
        subprocess.run(["npm", "install"], cwd=str(BASE), check=True)

    return True

def run_servers():
    """Inicia os servidores Flask e Next.js"""
    import subprocess
    import threading
    import webbrowser
    import time
    
    def run_flask():
        init_db()
        print("Backend Flask iniciado em http://localhost:4000")
        app.run(port=4000)

    def run_nextjs():
        from shutil import which
        print("Iniciando frontend Next.js...")
        try:
            npm_path = which("npm")
            if npm_path is None:
                print("Erro: npm não encontrado! Verificando se pnpm está disponível...")
                pnpm_path = which("pnpm")
                if pnpm_path is None:
                    print("Erro: nem npm nem pnpm foram encontrados. Verificando yarn...")
                    yarn_path = which("yarn")
                    if yarn_path is None:
                        print("Erro: Nenhum gerenciador de pacotes (npm/pnpm/yarn) encontrado!")
                        return
                    package_manager = "yarn"
                else:
                    package_manager = "pnpm"
            else:
                package_manager = "npm"
            
            # Use the absolute executable path returned by shutil.which to avoid
            # Windows "file not found" issues when calling via subprocess.
            if npm_path:
                pm_exec, pm_name = npm_path, "npm"
            elif pnpm_path:
                pm_exec, pm_name = pnpm_path, "pnpm"
            elif yarn_path:
                pm_exec, pm_name = yarn_path, "yarn"
            else:
                print("Nenhum gerenciador de pacotes encontrado para executar o frontend.")
                return

            print(f"Usando {pm_name} ({pm_exec}) para iniciar o projeto...")
            # Call the package manager executable directly
            subprocess.run([pm_exec, "run", "dev"], cwd=str(BASE), check=True)
        except subprocess.CalledProcessError as e:
            print(f"Erro ao executar {package_manager}:", e)
        except Exception as e:
            print("Erro inesperado ao iniciar o frontend:", e)

    # Inicia Flask em uma thread separada
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()

    # Aguarda um momento para o Flask iniciar
    time.sleep(2)

    # Inicia Next.js em uma thread separada
    next_thread = threading.Thread(target=run_nextjs, daemon=True)
    next_thread.start()

    # Aguarda um momento e abre o navegador
    time.sleep(3)
    print("\nAbrindo navegador em http://localhost:3000")
    webbrowser.open("http://localhost:3000")

    print("\nServidores rodando:")
    print("- Backend Flask: http://localhost:4000")
    print("- Frontend Next.js: http://localhost:3000")
    print("\nPressione Ctrl+C para encerrar ambos os servidores\n")

    try:
        # Mantém o programa rodando até Ctrl+C
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nEncerrando servidores...")

if __name__ == "__main__":
    if setup_environment():
        run_servers()
