# Instruções para iniciar o projeto com o wrapper Python

Este repositório é um projeto Next.js. Para facilitar a execução local, adicionei um pequeno wrapper Python (`server.py`) e um atalho `.bat` (`start_server.bat`) que automatizam a instalação (quando necessário) e a inicialização do projeto.

Pré-requisitos
- Node.js instalado (https://nodejs.org/) e disponível no PATH.
- pnpm ou npm ou yarn disponível no PATH (o script escolhe pnpm > npm > yarn automaticamente).
- Python 3.8+ para executar o wrapper (opcional — você pode usar `npm run dev` manualmente).


Como usar
1. Abra o Explorer do Windows e dê duplo clique em `start_server.bat`. Isso:
   - Criará automaticamente uma virtualenv em `.venv` (se não existir) usando `python -m venv .venv`.
   - Ativará a virtualenv e executará `server.py` dentro dela.
   - Se `node_modules` não existir, o script rodará `pnpm install` (ou `npm install`) automaticamente.
   - Iniciará o script `dev` (preferido) ou `start` definido em `package.json`.
   - Tentará abrir automaticamente `http://localhost:3000` no navegador após o servidor iniciar.

2. Alternativamente, abra um terminal (cmd/powershell) no diretório do projeto e rode manualmente:

```powershell
python -m venv .venv
.\.venv\Scripts\activate
python .\server.py
```

Opções úteis
- `python server.py --mode start` — força a execução do script `start` em vez de `dev`.

Observações
- O wrapper apenas automatiza comandos já definidos no `package.json` do projeto. Ele não substitui o Node.js/gerenciador de pacotes.
- Se preferir rodar manualmente, você sempre pode usar `pnpm dev`, `npm run dev` ou `npm run start` conforme desejar.

Problemas comuns
- Erro: "'node' não foi encontrado" — instale Node.js e reinicie o terminal.
- Erro de permissão durante `install` — abra um terminal com permissões adequadas e rode `pnpm install`/`npm install` manualmente.

Se quiser que eu modifique o comportamento (por exemplo, rodar `build` + `start` por padrão ou servir arquivos estáticos com um servidor Python simples), diga o que prefere e eu ajusto os scripts.
