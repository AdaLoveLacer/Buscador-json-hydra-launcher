export interface DownloadType {
  fileSize: string
  uploadDate: string
  uris: string[]
  title: string
  // source may be absent in uploaded JSON; make optional
  source?: string
}

export interface GogData {
  name: string
  downloads: DownloadType[]
}

export type GogSourcesStoreItem = { name: string; url: string; type: 'file' | 'url'; lastUpdated: string }
// Allow optionally storing the parsed data for "force" persistence of uploaded files or fetched URLs
export type GogSourcesStoreItemWithData = GogSourcesStoreItem & { data?: GogData }
