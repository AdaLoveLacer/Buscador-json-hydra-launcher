'use client'

import * as React from 'react'
import * as TabsPrimitive from '@radix-ui/react-tabs'

import { cn } from '@/lib/utils'

// Context to share a stable base id (from React.useId) between Tabs children
const TabsIdContext = React.createContext<string | null>(null)

function Tabs({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Root>) {
  const baseId = React.useId()
  return (
    <TabsIdContext.Provider value={baseId}>
      <TabsPrimitive.Root
        data-slot="tabs"
        className={cn('flex flex-col gap-2', className)}
        {...props}
      />
    </TabsIdContext.Provider>
  )
}

function TabsList({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.List>) {
  return (
    <TabsPrimitive.List
      data-slot="tabs-list"
      className={cn(
        'bg-muted text-muted-foreground inline-flex h-9 w-fit items-center justify-center rounded-lg p-[3px]',
        className,
      )}
      {...props}
    />
  )
}

function TabsTrigger({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Trigger>) {
  const baseId = React.useContext(TabsIdContext)
  const value = (props as any).value
  // If a consumer provided an id explicitly, keep it. Otherwise generate one
  const id = (props as any).id ?? (baseId ? `${baseId}-trigger-${String(value)}` : undefined)
  // aria-controls should point to content id when possible
  const ariaControls = (props as any)['aria-controls'] ?? (baseId ? `${baseId}-content-${String(value)}` : undefined)

  return (
    <TabsPrimitive.Trigger
      id={id}
      aria-controls={ariaControls}
      data-slot="tabs-trigger"
      className={cn(
        "data-[state=active]:bg-background dark:data-[state=active]:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring dark:data-[state=active]:border-input dark:data-[state=active]:bg-input/30 text-foreground dark:text-muted-foreground inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap transition-[color,box-shadow] focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:shadow-sm [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className,
      )}
      {...props}
    />
  )
}

function TabsContent({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Content>) {
  const baseId = React.useContext(TabsIdContext)
  const value = (props as any).value
  const id = (props as any).id ?? (baseId ? `${baseId}-content-${String(value)}` : undefined)
  const ariaLabelledBy = (props as any)['aria-labelledby'] ?? (baseId ? `${baseId}-trigger-${String(value)}` : undefined)

  return (
    <TabsPrimitive.Content
      id={id}
      aria-labelledby={ariaLabelledBy}
      data-slot="tabs-content"
      className={cn('flex-1 outline-none', className)}
      {...props}
    />
  )
}

export { Tabs, TabsList, TabsTrigger, TabsContent }
