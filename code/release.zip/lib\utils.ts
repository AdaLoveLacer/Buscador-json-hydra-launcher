import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function normalizeText(s?: string): string {
  if (!s) return '';
  return String(s)
    .toLowerCase()
    .trim();
}
