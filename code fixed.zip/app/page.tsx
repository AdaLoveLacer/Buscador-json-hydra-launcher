"use client"

import { useEffect } from "react"

export default function RootRedirectClient() {
  useEffect(() => {
    try {
      window.location.replace("/pt-BR")
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error("redirect failed", e)
    }
  }, [])

  return null
}
