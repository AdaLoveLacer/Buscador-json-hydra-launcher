"use client"

import { Card } from "@/components/ui/card"

interface SearchStatsProps {
  total: number
  filtered: number
  query: string
}

export default function SearchStats({ total, filtered, query }: SearchStatsProps) {
  const isFiltered = filtered !== total || query.length > 0

  return (
    <div className="mb-6 space-y-2">
      {isFiltered && (
        <Card className="p-4 bg-primary/5 border-primary/20">
          <p className="text-sm text-foreground">
            Mostrando <span className="font-semibold">{filtered}</span> de{" "}
            <span className="font-semibold">{total}</span> resultados
            {query && <span className="text-muted-foreground"> para "{query}"</span>}
          </p>
        </Card>
      )}
    </div>
  )
}
